﻿#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>
#include "User.h"
#include "Course.h"
#include "Presence.h"
#include "Score.h"
#include "Presence.h"
#include "GeneralFeatures.h"
#include "Academic_staff_features.h"
#include "Menu.h"
using namespace std;

int main() {
	main_menu();
	return 0;
}