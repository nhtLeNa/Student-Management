﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
//#include <conio.h>
#include <cstdlib>
#include <string>
#include <fstream>
#include <Windows.h>
#include <conio.h>
#include "console.h"
#include "GeneralFeatures.h"
#include "Menu.h"
#include "option_menu.h"
#include "Presence.h"
#include "Score.h"
#include "Course.h"
#include "User.h"
#include "Academic_staff_features.h"
#define TEXTCOLOR 48
#define BGCOLOR 55
using namespace std;

//enum STATE { UP, DOWN, LEFT, RIGHT, ENTER, BACK };
typedef char options[100];

void main_menu() {
	system("color 30");
	loginMenu();
}
STATE key(int z)
{
	if (z == 224)
	{
		char c = _getch();
		if (c == 72)
			return UP;
		if (c == 80)
			return DOWN;
		if (c == 77)
			return RIGHT;
		if (c == 75)
			return LEFT;
	}
	else if (z == 13)
		return ENTER;
}
int Roll(options menu1[], int n, int k) {
	int *color = new int[n];
	for (int i = 0; i < n; i++)
		color[i] = TEXTCOLOR;
	color[0] = BGCOLOR;
	int state_num = 0;
	while (true) {
		clrscr();
		TextColor(48);
		gotoXY(0, 1);
		cout << "\t\t\t\t\t\t ===STAFF MENU OPTIONS===\n\n\n";
		for (int i = 0; i < n; i++) {
			TextColor(color[i]);
			for (int j = 0; j < k; j++) cout << "\t";
			cout << i + 1 << "-" << menu1[i] << "\n\n";
		}
		TextColor(48);
		int z = _getch();
		STATE state = key(z);
		switch (state)
		{
		case UP: {
			if (state_num == 0)
				state_num = n - 1;
			else
				state_num--;
			break;
		}
		case DOWN: {
			if (state_num == n - 1)
				state_num = 0;
			else
				state_num++;
			break;
		}
		case ENTER: {
			return state_num;
		}
		}
		for (int i = 0; i < n; i++)
			color[i] = TEXTCOLOR;
		color[state_num] = BGCOLOR;
	}
}
void loginMenu() {
	clrscr();
	TextColor(48);
	int *color = new int[2];
	for (int i = 0; i < 2; i++)
		color[i] = TEXTCOLOR;
	color[0] = BGCOLOR;
	STATE state;
	int state_num = 0, z;
	User current_login;
	while (true) {
		//clrscr();
		TextColor(48);
		gotoXY(0, 1);
		cout << "\t\t\t\t\t\t" << "STUDENT MANAGEMENT SYSTEM" << endl;
		cout << "\n\n\n";
		TextColor(color[0]);
		cout << "\t\t\t\t\t\t\t" << "LOGIN" << endl;
		cout << "\n\n\n";
		TextColor(color[1]);
		cout << "\t\t\t\t\t\t\t" << "EXIT" << endl;
		TextColor(BGCOLOR);
		z = _getch();
		state = key(z);
		switch (state) {
		case UP: {
			if (state_num == 0)
				state_num = 1;
			else
				state_num--;
			break;
		}
		case DOWN: {
			if (state_num == 1)
				state_num = 0;
			else
				state_num++;
			break;
		}
		case ENTER:
			break;
		}
		if (state == ENTER)
			if (state_num == 1) {
				//log out
				return;
			}
			else {
				clrscr();
				User* cur_user = nullptr;
				login(cur_user);
				//cout << cur_user->getType();
				switch (cur_user->getType()) {
				case '1': {
					vector<User> list_user;
					vector<Course> list_course;
					return staffMenu(list_user, list_course);
				}
				case '2': {
					Scoreboard score;
					return lectureMenu(score);
				}
				case '0': {
					st_menu(5, cur_user);
					return;
				}
				}
			}
		for (int i = 0; i < 2; i++)
			color[i] = TEXTCOLOR;
		color[state_num] = BGCOLOR;

	}
}
void staffMenu(vector<User> &list_user, vector<Course> &list_course){
	options menu1[6] ={"CLASSES","COURSES","COURSES'S SCHEDULES","ATTENDANCE LIST OF COURSE","SCOREBOARD OF A COURSE","LOGOUT"};
	int state_num = Roll(menu1, 6, 7);
	//cout << state_num;
	staff_option(state_num, list_user, list_course);
}
void staffMenuClass(vector<User> &list_user, vector<Course> &list_course) {
	options menu1[9] = { "IMPORT STUDENTS OF A CLASS","ADD NEW STUDENT TO CLASS","EDIT AN EXISTING STUDENT",
		"REMOVE STUDENT","CHANGE STUDENTS FROM CLASS TO ANOTHER CLASS","ADD NEW EMPTY CLASS",
		"VIEW LIST OF CLASSES","VIEW LIST OF STUDENTS IN CLASS","RETURN TO MENU" };
	int state_num = Roll(menu1, 9, 6);
	staff_option_class(state_num, list_user, list_course);
}
void staffMenuCourse(vector<User> &list_user, vector<Course> &list_course) {
	options menu1[6] = { "IMPORT COURSE","ADD NEW COURSE","EDIT AN EXISTING COURSE",
		"REMOVE COURSE","VIEW LIST OF COURSE","RETURN TO MENU" };
	int state_num = Roll(menu1, 6, 7);
	vector<User> list;
	staff_option_course(state_num, list_user, list_course);
}
void staffMenuSchedule(vector<User> &list_user, vector<Course> &list_course) {
	options menu1[6] = { "IMPORT COURSES'S SCHEDULES","ADD COURSES'S SCHEDULE","EDIT AN EXISTING COURSES'S SCHEDULE",
		"REMOVE COURSES'S SCHEDULE","VIEW LIST OF SCHEDULES","RETURN TO MENU" };
	int state_num = Roll(menu1, 6, 5);
	staff_option_schedule(state_num, list_user, list_course);
}
void staffMenuAttendance(Attendance &att, vector<User> &list_user, vector<Course> &list_course) {
	options menu1[3] = { "SEARCH ATTENDANCE LIST OF COURSE","SEARCH SCOREBOARD OF A COURSE","RETURN TO MENU" };
	int state_num = Roll(menu1, 3, 4);
	staff_option_attendance(state_num, att, list_user, list_course);
}
void staffMenuScore(Scoreboard &score, vector<User> &list_user, vector<Course> &list_course) {
	options menu1[3] = {"EXPORT ATTENDANCE LIST","EXPORT SCOREBOARD","RETURN TO MENU" };
	int state_num = Roll(menu1, 3, 5);
	staff_option_score(state_num, score, list_user, list_course);
}
void staffMenuEditStudent(User *&user, vector<User> &list_user, vector<Course> &list_course) {
	options menu1[6] = { "USER NAME","FULL NAME","MOBILE PHONE","PASS WORD", "CLASS", "RETURN TO MENU" };
	int state_num = Roll(menu1, 6, 6);
	staff_option_edit_student(state_num, user, list_user, list_course);
}
void staffMenuEditCourse(Course *&c, vector<User> &list_user, vector<Course> &list_course) {
	options menu1[11] = {"COURSE'S CODE","YEAR","SEMESTER","COURSE'S NAME", "LECTURE'S USERNAME", "START DATE", "END DATE", "START TIME", "END TIME", "DAY OF WEEK", "RETURN TO MENU"};
	int state_num = Roll(menu1, 11, 6);
	staff_option_edit_course(state_num, c, list_user, list_course);
}
void lectureMenu(Scoreboard &score) {
	options menu1[4] = {"IMPORT SCOREBOARD OF A COURSE","EDIT GRADE OF STUDENT","VIEW SCOREBOARD" ,"LOGOUT" };
	int state_num = Roll(menu1, 4, 5);
	lecture_option(state_num, score);
}
void lectureMenuEdit(Scoreboard &score, Score &student_score) {
	options menu1[5] = { "MIDTERM SCORE","LAB SCORE","FINAL SCORE", "BONUS" ,"RETURN TO MENU" };
	int state_num = Roll(menu1, 5, 6);
	lecture_option_edit(state_num, score, student_score);
}
//-------------------------------------------------------------------------------------
// yen 
void frame()
{
	gotoXY(2, 1);
	for (int i = 0; i < 115; i++)
	{
		TextColor(7);
		printf("%c", 219);
	}
	int j = 2;
	for (int i = 0; i < 27; i++)
	{
		gotoXY(2, j);
		TextColor(7);
		printf("%c%c\n", 219, 219);
		j++;
	}
	gotoXY(2, 28);
	for (int i = 0; i < 115; i++)
	{
		TextColor(7);
		printf("%c", 219);
	}
	int k = 1;
	for (int i = 0; i < 28; i++)
	{
		gotoXY(116, k);
		TextColor(7);
		printf("%c%c\n", 219, 219);
		k++;
	}
	TextColor(TEXTCOLOR);
}
void addcourseframe(int x, int y, int z, int v, int j, int k, int m)
{
	//gotoXY(20, 3);
	gotoXY(x, y);
	for (int i = 0; i < z; i++)
	{
		TextColor(55);
		printf("%c", 95);
	}
	for (int i = 0; i < v; i++)
	{
		gotoXY(19, j);
		TextColor(55);
		printf("%c", 124);
		j++;
	}
	gotoXY(x, y + v);
	for (int i = 0; i < z; i++)
	{
		TextColor(55);
		printf("%c", 95);
	}
	for (int i = 0; i < v; i++)
	{
		gotoXY(x + z, k);
		TextColor(55);
		printf("%c", 124);
		k++;
	}
	for (int i = 0; i < v; i++)
	{
		gotoXY(x + 35, m);
		TextColor(55);
		printf("%c", 124);
		m++;
	}
	TextColor(TEXTCOLOR);
}
int st_menu(int n, User *user)
{
	int st = 0;//Bien chi dang o thao tac thu nhat
	typedef char str[30];
	str menu1[4] = { "CHECKIN RESULT","SCOREBOARD","SCHEDULES","LOGOUT" };
	int *color = new int[n];
	for (int i = 0; i < n; i++)
		color[i] = TEXTCOLOR;
	color[0] = BGCOLOR;//thao tac thu nhat
	vector<Course> test1;
	import_course("3.csv", test1);
	while (true)
	{
		clrscr();
		gotoXY(0, 0);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		TextColor(58);
		gotoXY(57, 1);
		cout << "MENU" << endl;
		gotoXY(0, 2);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		for (int i = 0; i < n - 1; i++)
		{
			TextColor(color[i]);
			cout << "\n\n" << endl;
			cout << "\t\t\t\t\t\t\t" << i + 1 << "." << menu1[i] << endl;
		}
		TextColor(color[n - 1]);
		gotoXY(4, 23);
		cout << menu1[n - 1] << endl;
		gotoXY(0, 26);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		gotoXY(0, 28);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		int z = _getch();
		STATE state = key(z);
		switch (state)
		{
		case UP:
		{
			if (st == 0)
			{
				st = n - 1;
			}
			else
			{
				st--;
			}
			break;
		}
		case DOWN:
		{
			if (st == n - 1)
			{
				st = 0;
			}
			else
			{

				st++;
			}
			break;

		}
		case ENTER:
			if (st == 0)
			{
				system("cls");
				frame();
				string x;
				gotoXY(45, 13);
				cout << "Enter course code:";
				getline(cin, x, '\n');
				import_course("Course.csv", test1);
				system("cls");
				frame();
				if (user->check_in(x, test1))
				{
					gotoXY(45, 13);
					cout << "SUCCESS";
				}
				else
				{
					gotoXY(45, 13);
					cout << "FAIL";
				}
				system("pause");
				system("cls");
			}
			if (st == 1)
			{
				system("cls");
				frame();
				string x;
				gotoXY(45, 13);
				cout << "Enter course code:";
				getline(cin, x, '\n');
				system("cls");
				Scoreboard temp;
				import_scoreboard(x, temp);
				viewscore(1, user, temp, x);
				//viewscore(x, temp,user);
			}
			if (st == 2)
				viewsch(1, user, "3.csv", test1);
			if (st == n - 1)
			{
				exit(0);
			}
		}
		for (int i = 0; i < n; i++)
			color[i] = TEXTCOLOR;
		color[st] = BGCOLOR;

	}
	delete color;
}
int viewscore(int n, User *user, Scoreboard &temp, string course)
{
	int st = 0;//Bien chi dang o thao tac thu nhat
	typedef char str[30];
	str menu1[1] = { "BACK" };
	int *color = new int[n];
	for (int i = 0; i < n; i++)
		color[i] = TEXTCOLOR;
	color[0] = BGCOLOR;//thao tac thu nhat
	vector<Course> test1;
	import_course("3.csv", test1);
	while (true)
	{
		system("cls");
		ifstream fi(".\\Scores\\" + course + ".csv");
		if (!fi) {
			cerr << "Course Scoreboard not exit" << endl;
			return st_menu(4, user);
		}
		score_list list;
		gotoXY(0, 0);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		TextColor(58);
		gotoXY(57, 1);
		cout << course << endl;
		gotoXY(0, 2);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		gotoXY(0, 26);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		gotoXY(0, 28);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		gotoXY(40, 4);
		cout << "MIDTERM";
		gotoXY(55, 4);
		cout << "|";
		gotoXY(65, 4);
		cout << "LAB ";
		gotoXY(80, 4);
		cout << "|";
		gotoXY(85, 4);
		cout << "FINAL";
		gotoXY(95, 4);
		cout << "|";
		gotoXY(100, 4);
		cout << "BONUS";
		int k = 6;

		for (auto it = temp.data.begin(); it != temp.data.end(); ++it)
		{
			if (it->ID == user->getUsername())
			{
				gotoXY(40, k);
				cout << it->score.midterm;
				gotoXY(55, k);
				cout << "|";
				gotoXY(65, k);
				cout << it->score.lab;
				gotoXY(80, k);
				cout << "|";
				gotoXY(85, k);
				cout << it->score.final;
				gotoXY(95, k);
				cout << "|";
				gotoXY(100, k);
				cout << it->score.bonus;
			}
		}
		fi.close();
		TextColor(color[n - 1]);
		gotoXY(4, 23);
		cout << menu1[n - 1] << endl;
		int z = _getch();
		STATE state = key(z);
		switch (state)
		{
		case UP:
		{
			if (st == 0)
			{
				st = n - 1;
			}
			else
			{
				st--;
			}
			break;
		}
		case DOWN:
		{
			if (st == n - 1)
			{
				st = 0;
			}
			else
			{

				st++;
			}
			break;

		}
		case ENTER:
		{
			if (st == n - 1)
				st_menu(4, user);
		}
		for (int i = 0; i < n; i++)
			color[i] = TEXTCOLOR;
		color[st] = BGCOLOR;
		}
	}
	delete color;
}
int viewsch(int n, User *user, string path, vector<Course> &list)
{
	int st = 0;//Bien chi dang o thao tac thu nhat
	typedef char str[30];
	str menu1[1] = { "BACK" };
	int *color = new int[n];
	for (int i = 0; i < n; i++)
		color[i] = TEXTCOLOR;
	color[0] = BGCOLOR;//thao tac thu nhat
	import_course("3.csv", list);
	while (true)
	{
		system("cls");
		ifstream fi(path);
		if (!fi) {
			cerr << "Course Schedule not exit" << endl;
			return st_menu(4, user);
		}
		gotoXY(0, 0);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		TextColor(58);
		gotoXY(57, 1);
		cout << "SCHEDULE" << endl;
		gotoXY(0, 2);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		gotoXY(0, 26);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		gotoXY(0, 28);
		for (int i = 0; i < 120; i++)
		{
			TextColor(48);
			printf("%c", 61);
		}
		gotoXY(2, 4);
		cout << "Course Code ";
		gotoXY(15, 4);
		cout << "|";
		gotoXY(20, 4);
		cout << "Lecture name ";
		gotoXY(34, 4);
		cout << "|";
		gotoXY(37, 4);
		cout << "Start Date ";
		gotoXY(50, 4);
		cout << "|";
		gotoXY(55, 4);
		cout << "End Date";
		gotoXY(70, 4);
		cout << "|";
		gotoXY(75, 4);
		cout << "Start Hour ";
		gotoXY(90, 4);
		cout << "|";
		gotoXY(95, 4);
		cout << "End Hour ";
		gotoXY(105, 4);
		cout << "|";
		gotoXY(110, 4);
		cout << "DoW";
		int k = 6;
		for (int i = 0; i < list.size() - 5; ++i)
		{
			gotoXY(2, k);
			cout << list[i].getCourseCode();
			gotoXY(15, k);
			cout << "|";
			gotoXY(20, k);
			cout << list[i].getLecUsername();
			gotoXY(34, k);
			cout << "|";
			gotoXY(37, k);
			cout << list[i].getStartDate().day << "/" << list[i].getStartDate().month << "/" << list[i].getStartDate().year;
			gotoXY(50, k);
			cout << "|";
			gotoXY(55, k);
			cout << list[i].getEndDate().day << "/" << list[i].getEndDate().month << "/" << list[i].getEndDate().year;
			gotoXY(70, k);
			cout << "|";
			gotoXY(75, k);
			cout << list[i].getStartTime().hour << "h" << list[i].getStartTime().minute;
			gotoXY(90, k);
			cout << "|";
			gotoXY(95, k);
			cout << list[i].getEndTime().hour << "h" << list[i].getEndTime().minute;
			gotoXY(105, k);
			cout << "|";
			gotoXY(111, k);
			cout << list[i].getDoW() << endl;
			k++;
		}
		TextColor(color[n - 1]);
		fi.close();
		gotoXY(4, 23);
		cout << menu1[n - 1] << endl;
		int z = _getch();
		STATE state = key(z);
		switch (state)
		{
		case UP:
		{
			if (st == 0)
			{
				st = n - 1;
			}
			else
			{
				st--;
			}
			break;
		}
		case DOWN:
		{
			if (st == n - 1)
			{
				st = 0;
			}
			else
			{

				st++;
			}
			break;

		}
		case ENTER:
		{
			if (st == n - 1)
				st_menu(4, user);
		}
		for (int i = 0; i < n; i++)
			color[i] = TEXTCOLOR;
		color[st] = BGCOLOR;
		}
	}
	delete color;
}