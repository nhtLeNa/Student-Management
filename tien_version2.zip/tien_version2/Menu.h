#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <Windows.h>
#include "User.h"
#include "Course.h"
#include "Presence.h"
#include "Score.h"

// yen
enum STATE { UP, DOWN, LEFT, RIGHT, ENTER, BACK };
STATE key(int z);
void frame();
void addcourseframe(int x, int y, int z, int v, int j, int k, int m);
int st_menu(int n, User *user);
int viewscore(int n, User *user, Scoreboard &temp, string course);
int viewsch(int n, User *user, string path, vector<Course> &list);
//void menu(int n);
//tien
//int Roll(options menu1[], int n, int k);
void staffMenu(vector<User> &list_user, vector<Course> &list_course);
void staffMenuClass(vector<User> &list_user, vector<Course> &list_course);
void staffMenuCourse(vector<User> &list_user, vector<Course> &list_course);
void staffMenuSchedule(vector<User> &list_user, vector<Course> &list_course);
void staffMenuAttendance(Attendance &att, vector<User> &list_user, vector<Course> &list_course);
void staffMenuScore(Scoreboard &score, vector<User> &list_user, vector<Course> &list_course);

void staffMenuEditStudent(User *&user, vector<User> &list_user, vector<Course> &list_course);
void staffMenuEditCourse(Course *&c, vector<User> &list_user, vector<Course> &list_course);

void lectureMenu(Scoreboard &score);
void lectureMenuEdit(Scoreboard &score, Score &student_score );

void loginMenu();
void main_menu();