#include "option_menu.h"
#include "Menu.h"
#include "GeneralFeatures.h"
#include "Academic_staff_features.h"
#include "Score.h"
#include "Presence.h"

void staff_option(int state_num, vector<User> &list_user, vector<Course> list_course) {
	system("cls");
	if (state_num == 0) return staffMenuClass(list_user, list_course);
	if (state_num == 1) return staffMenuCourse(list_user, list_course);
	if (state_num == 2) return staffMenuSchedule(list_user, list_course);
	if (state_num == 3) {
		Attendance att;
		string cours_code;
		cout << "Enter course's code: ";
		getline(cin, cours_code, '\n');
		import_attendance(cours_code, att);
		return staffMenuAttendance(att, list_user, list_course);
	}
	if (state_num == 4) {
		Scoreboard score;
		string cours_code;
		cout << "Enter coures's code: ";
		getline(cin, cours_code, '\n');
		import_scoreboard(cours_code, score);
		return staffMenuScore(score, list_user, list_course);
	}
	if (state_num == 5) return loginMenu();
}
void staff_option_class(int state_num, vector<User> &list_user, vector<Course> &list_course) {
	system("cls");
	cout << "\t\t\t\t\t\tSTAFF -> CLASS" << endl;
	switch (state_num) {
	case 0: {
		string path;
		cout << "\t\t\ Enter csv file's name: ";
		getline(cin, path, '\n');
		import_students(path, list_user);
	}
	case 1:{
		add_new_student(list_user);
	}
	case 2: {
		cout << "Enter student ID to edit: ";
		string id;
		getline(cin, id, '\n');
		for(auto &i : list_user)
			if (i.getUsername() == id) {
				User *u = &i;
				return staffMenuEditStudent(u, list_user, list_course);
			}
	}
	case 3: {
		cout << "Enter student ID to remove: ";
		string id;
		getline(cin, id, '\n');
		remove_student(list_user, id);
	}
	case 4: {
		change_class(list_user);
	}
	case 5: {
		cout << "Enter new class name: ";
		string name;
		getline(cin, name, '\n');
		add_new_class(name);
	}
	case 6: {
		print_list_of_class();
	}
	case 7: {
		cout << "Enter name of class: ";
		string name;
		getline(cin, name, '\n');
		print_student_list(name);
	}
	case 8: {
		staffMenu(list_user, list_course);
	}
	}
	return staffMenuClass(list_user, list_course);
}
void staff_option_course(int state_num, vector<User> &list_user, vector<Course> &list_course) {
	system("cls");
	cout << "\t\t\t\t\t\tSTAFF -> COURSE" << endl;
	switch (state_num) {
	case 0: {
		string path;
		cout << "\t\t\ Enter csv file's name: ";
		getline(cin, path, '\n');
		import_course(path, list_course);
	}
	case 1: {
		add_new_course(list_course);
	}
	case 2: {
		cout << "Enter coure's code to edit";
		string code;
		getline(cin, code, '\n');
		for(auto &i:list_course)
			if (i.getCourseCode() == code) {
				Course *c = &i;
				return staffMenuEditCourse(c, list_user, list_course);
			}
	}
	case 3:{
		remove_course(list_course);
	}
	case 4: {
		vector<string> list_course = read_directory();
		cout << "List of courses\n";
		for (auto &i : list_course)
			cout << i;
	}
	case 5: {
		return staffMenu(list_user, list_course);
	}
	}
	return staffMenuCourse(list_user, list_course);
}
void staff_option_schedule(int state_num, vector<User> &list_user, vector<Course> &list_course) {
	system("cls");
	cout << "\t\t\t\t\t\tSTAFF -> COURSE'S SCHEDULE" << endl;
	switch (state_num) {
	case 0: {
		string path;
		cout << "\t\t\ Enter csv file's name: ";
		getline(cin, path, '\n');
		import_course(path, list_course);
	}
	case 1: {
		add_new_course(list_course);
	}
	case 2: {
		cout << "Enter coure's code to edit its schedule: ";
		string code;
		getline(cin, code, '\n');
		for (auto &i : list_course)
			if (i.getCourseCode() == code) {
				Course *c = &i;
				return staffMenuEditCourse(c, list_user, list_course);
			}
	}
	case 3: {
		remove_course(list_course);
	}
	case 4: {
		vector<string> list_course = read_directory();
		cout << "List of schedule\n";
		for (auto &i : list_course)
			cout << i;
	}
	case 5: {
		return staffMenu(list_user, list_course);
	}
	}
	return staffMenuSchedule(list_user, list_course);
}
void staff_option_attendance(int state_num, Attendance &att, vector<User> &list_user, vector<Course> &list_course) {
	system("cls");
	cout << "\t\t\t\t\t\tSTAFF -> SEARCH " << endl;
	switch (state_num) {
	case 0: {
		cout << "Enter course's code to seacrch: ";
		string code;
		getline(cin, code, '\n');
		if (code == att.Course_code) {
			cout << "Course's code " << att.Course_code;
			cout << "ID - name - check in" << endl;
			for (auto &i : att.attendance_list) {
				cout << i.ID << " " << i.name << " " << i.check_in << endl;
			}
		}
		else
			cout << "Course no found!";
	}
	case 1: {
		export_attendance(att);
		cout << "Successfull!";
	}
	case 2: {
		return staffMenu(list_user, list_course);
	}
	}
	return staffMenuAttendance(att, list_user, list_course);
}
void staff_option_score(int state_num, Scoreboard &score, vector<User> &list_user, vector<Course> &list_course) {
	system("cls");
	cout << "\t\t\t\t\t\tSTAFF -> SCORE BOARD " << endl;
	switch (state_num) {
	case 0: {
		cout << "Enter course's code to seacrch: ";
		string code;
		getline(cin, code, '\n');
		if (code == score.Course_code) {
			cout << "Course's code: " << score.Course_code << endl;
			cout << "Score ID - midterm - lab - final - bonus" << endl;
			for (auto &i : score.data) {
				cout << " " << i.ID << " " << i.score.midterm << " " << i.score.lab << " " << i.score.final << " " << i.score.bonus << endl;
			}
		}
		else
			cout << "Course not found! ";
	}
	case 1: {
		export_scoreboard(score);
		cout << "successfull!";
	}
	case 2: {
		return staffMenu(list_user, list_course);
	}
	}
	return staffMenuScore(score, list_user, list_course);
}
void staff_option_edit_student(int state_num, User *&user, vector<User> &list_user, vector<Course> &list_course) {
	system("cls");
	switch (state_num) {
	case 0: {
		cout << "Enter new user name: ";
		string name;
		getline(cin, name, 'n');
		user->setUsername(name);
	}
	case 1: {
		cout << "Enter new full name: ";
		string name;
		getline(cin, name, '\n');
		user->setName(name);
	}
	case 2: {
		cout << "Enter new email: ";
		string phone;
		getline(cin, phone, '\n');
		user->setPhone(phone);
	}
	case 3: {
		cout << "Enter new password: ";
		string pass;
		getline(cin, pass, '\n');
		user->setPassword(pass);
	}
	case 4: {
		cout << "Enter new class: ";
		string newclass;
		getline(cin, newclass, '\n');
		user->setClass(newclass);
	}
	case 5: {
		return staffMenuClass(list_user, list_course);
	}
	}
	return staffMenuEditStudent(user, list_user, list_course);
}
void staff_option_edit_course(int state_num, Course *&course, vector<User> &list_user, vector<Course> &list_course) {
	system("cls");
	switch (state_num) {
	case 0: {
		cout << "Enter new course's code: ";
		string code;
		getline(cin, code, '\n');
		course->setCourseCode(code);
	}
	case 1: {
		cout << "Enter new course's year: ";
		string year;
		getline(cin, year, '\n');
		course->setYear(year);
	}
	case 2: {
		cout << "Enter new course's semester: ";
		int s;
		cin >> s;
		course->setSemester(s);
	}
	case 3: {
		cout << "Enter new course's name: ";
		string name;
		getline(cin, name, '\n');
		course->setName(name);
	}
	case 4: {
		cout << "Enter new course's lecture's username: ";
		string name;
		getline(cin, name, '\n');
		course->setLecUsername(name);
	}
	case 5: {
		cout << "Enter new course's start date\n ";
		date d;
		cout << "Enter day\n ";
		cin >> d.day;
		cout << "Enter month\n ";
		cin >> d.month;
		cout << "Enter year\n ";
		cin >> d.year;
		course->setStartDate(d);
	}
	case 6: {
		cout << "Enter new course's end day: ";
		date d;
		cout << "Enter day\n ";
		cin >> d.day;
		cout << "Enter month\n ";
		cin >> d.month;
		cout << "Enter year\n ";
		cin >> d.year;
		course->setEndDate(d);
	}
	case 7: {
		cout << "Enter new course's start time\n ";
		ttime t;
		cout << "Enter hour\n ";
		cin >> t.hour;
		cout << "Enter minute\n ";
		cin >> t.minute;
		course->setStartTime(t);
	}
	case 8: {
		cout << "Enter new course's end time\n ";
		ttime t;
		cout << "Enter hour\n ";
		cin >> t.hour;
		cout << "Enter minute\n ";
		cin >> t.minute;
		course->setEndTime(t);
	}
	case 9: {
		cout << "Enter new day of week (number 2/3/4...): ";
		int day;
		cin >> day;
		course->setDoW(day);
	}
	case 10: {
		return staffMenuCourse(list_user, list_course);
	}
	}
	return staffMenuEditCourse(course, list_user, list_course);
}
void lecture_option(int state_num, Scoreboard &score) {
	system("cls");
	if (state_num == 0) {
		string cours_code;
		cout << "Enter coures's code: ";
		getline(cin, cours_code, '\n');
		import_scoreboard(cours_code, score);
		return lectureMenu(score);
	}
	if (state_num == 1) {
		cout << "Course's code: " << score.Course_code << endl;
		cout << "Enter student ID to edit: ";
		string id;
		getline(cin, id, '\n');
		for(auto &i : score.data)
			if (i.ID == id) {
				lectureMenuEdit(score, i);
			}
	}
	if (state_num == 2) {
		cout << "Scoreboard" << endl;
		cout << "Student ID - midterm score - lab score - final score - bonus" << endl;
		for (auto &i : score.data) {
			cout << i.ID << " " << i.score.midterm << " " << i.score.lab << " " << i.score.final << " " << i.score.bonus << endl;
		}
	}
	if (state_num == 3) {
		return loginMenu();
	}
	return lectureMenu(score);
}
void lecture_option_edit(int state_num, Scoreboard &score, Score &student_score) {
	system("cls");
	switch (state_num) {
	case 0: {
		cout << "Enter new midterm score: ";
		double d;
		cin >> d;
		student_score.score.midterm = d;
	}
	case 1: {
		cout << "Enter new lab score: ";
		double d;
		cin >> d;
		student_score.score.lab = d;
	}
	case 2: {
		cout << "Enter new final score: ";
		double d;
		cin >> d;
		student_score.score.final = d;
	}
	case 3: {
		cout << "Enter new bonus score: ";
		double d;
		cin >> d;
		student_score.score.bonus = d;
	}
	case 4: {
		return lectureMenu(score);
	}
	}
	return lectureMenuEdit(score, student_score);
}