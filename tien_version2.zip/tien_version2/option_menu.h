#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <Windows.h>
#include "User.h"
#include "Course.h"
#include "Presence.h"
#include "Score.h"
void staff_option(int state_num, vector<User> &list_user, vector<Course> list_course);
void staff_option_class(int n, vector<User> &list_user, vector<Course> &list_course);
void staff_option_edit_student(int n, User *&user, vector<User> &list_user, vector<Course> &list_course);
void staff_option_course(int n, vector<User> &list_user, vector<Course> &list_course);
void staff_option_edit_course(int n, Course *&c, vector<User> &list_user, vector<Course> &list_course);
void staff_option_schedule(int n, vector<User> &list_user, vector<Course> &list_course);
void staff_option_attendance(int n, Attendance &att, vector<User> &list_user, vector<Course> &list_course);
void staff_option_score(int n, Scoreboard &score, vector<User> &list_user, vector<Course> &list_course);
void lecture_option(int n, Scoreboard &score);
void lecture_option_edit(int n, Scoreboard &score, Score &student_score);
void student_option(int n);
